<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Books;

class BooksController extends Controller
{
    public function addUserBooks(Request $request)
    {
        // return $request->file('thumbnail');

        $data = [
            'title'=>$request->title,
            'subtitle'=>$request->subtitle,
            'authors'=>$request->authors,
            'small_thumbnail'=>'$request->small_thumbnail',
            'thumbnail'=>'$request->thumbnail',
            'user_id'=>$request->user_id
        ];
         $result =  Books::create($data);
         if($result){
            return response('Books added successfully!',200);
         }else{
            return response('Somthing went wroung!',201);
         }
    }

    public function getBooks($id)
    {
        return Books::where('user_id',$id)->get();
    }
}
